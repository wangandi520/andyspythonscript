import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    let disposable = vscode.commands.registerCommand('number-incrementer.increment', () => {
        const editor = vscode.window.activeTextEditor;
        // 检查编辑器是否存在
        if (!editor) {
            vscode.window.showErrorMessage('没有打开的编辑器');
            return;
        }
        const position = editor.selection.active;
        const line = editor.document.lineAt(position.line);
        const lineText = line.text;
        // 查找第二个和第三个竖线的位置
        const firstPipeIndex = lineText.indexOf('|');
        const secondPipeIndex = lineText.indexOf('|', firstPipeIndex + 1);
        const thirdPipeIndex = lineText.indexOf('|', secondPipeIndex + 1);
        // 提取第二个和第三个竖线之间的内容
        const content = lineText.substring(secondPipeIndex + 1, thirdPipeIndex);
        // 查找内容中的数字（包括小数点）
        const numberMatch = content.match(/\d+(\.\d+)?/);
        // 提取数字
        if (!numberMatch) {
            vscode.window.setStatusBarMessage('未找到可自增的数字', 3000);
            return;
        }
        const originalNumber = numberMatch[0];
        let incrementedNumber;
        // 检查是否包含小数点
        if (originalNumber.includes('.')) {
            // 如果是小数，只增加小数点后面的部分
            const parts = originalNumber.split('.');
            const integerPart = parts[0];
            const decimalPart = parseInt(parts[1]) + 1;
            incrementedNumber = `${integerPart}.${decimalPart}`;
        } else {
            // 如果是整数，直接加1
            incrementedNumber = (parseInt(originalNumber) + 1).toString();
        }
        // 替换内容中的数字
        const newContent = content.replace(originalNumber, incrementedNumber);
        
        // 构建新的行文本
        const newLineText = lineText.substring(0, secondPipeIndex + 1) + 
                            newContent + 
                            lineText.substring(thirdPipeIndex);
        // 替换整行文本
        editor.edit(editBuilder => {
            editBuilder.replace(line.range, newLineText);
        }).then(success => {
            if (success) {
                vscode.window.setStatusBarMessage('数字已成功增加', 3000);

                // 数字自增后，尝试将当前行移动到表格首行
                const document = editor.document;
                const totalLines = document.lineCount;
                let headerLine = -1;
                let separatorLine = -1;
                // 向上查找表头和分隔线
                for (let i = position.line; i >= 0; i--) {
                    const text = document.lineAt(i).text.trim();
                    if (text.match(/^\|\s*[-:]+\s*\|/)) {
                        separatorLine = i;
                        // 继续向上找表头
                        for (let j = i - 1; j >= 0; j--) {
                            const headerText = document.lineAt(j).text.trim();
                            if (headerText.startsWith('|') && headerText.endsWith('|')) {
                                headerLine = j;
                                break;
                            }
                        }
                        break;
                    }
                }
                if (headerLine !== -1 && separatorLine !== -1 && position.line > separatorLine) {
                    // 重新获取已更新的行内容
                    const updatedLineText = document.lineAt(position.line).text;
                    editor.edit(editBuilder => {
                        // 删除当前行
                        editBuilder.delete(document.lineAt(position.line).rangeIncludingLineBreak);
                        // 在分隔线下插入
                        const insertPos = document.lineAt(separatorLine).range.end;
                        editBuilder.insert(insertPos, '\n' + updatedLineText);
                    }).then(moveSuccess => {
                        if (moveSuccess) {
                            vscode.window.setStatusBarMessage('数字已增加并移动到表格首行', 3000);
                            setTimeout(() => {
                                const newLine = separatorLine + 1;
                                const newLineRange = document.lineAt(newLine).range;
                                const newSelection = new vscode.Selection(newLineRange.start, newLineRange.start);
                                editor.selection = newSelection;
                                editor.revealRange(newLineRange, vscode.TextEditorRevealType.InCenter);
                            }, 50);
                        }
                    });
                }
            } else {
                vscode.window.setStatusBarMessage('编辑操作失败', 3000);
            }
        });
    });

    context.subscriptions.push(disposable);
}

export function deactivate() {}