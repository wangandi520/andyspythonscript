import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    let disposable = vscode.commands.registerCommand('number-incrementer.increment', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showInformationMessage('没有打开的编辑器');
            return;
        }

        const position = editor.selection.active;
        const line = editor.document.lineAt(position.line);
        const lineText = line.text;

        // 查找第二个和第三个竖线的位置
        const firstPipeIndex = lineText.indexOf('|');
        if (firstPipeIndex === -1) {
            vscode.window.showInformationMessage('当前行没有找到竖线符号');
            return;
        }

        const secondPipeIndex = lineText.indexOf('|', firstPipeIndex + 1);
        if (secondPipeIndex === -1) {
            vscode.window.showInformationMessage('当前行没有找到第二个竖线符号');
            return;
        }

        const thirdPipeIndex = lineText.indexOf('|', secondPipeIndex + 1);
        if (thirdPipeIndex === -1) {
            vscode.window.showInformationMessage('当前行没有找到第三个竖线符号');
            return;
        }

        // 提取第二个和第三个竖线之间的内容
        const content = lineText.substring(secondPipeIndex + 1, thirdPipeIndex);
        
        // 查找内容中的数字（包括小数点）
        const numberMatch = content.match(/\d+(\.\d+)?/);
        if (!numberMatch) {
            vscode.window.showInformationMessage('在指定区域内没有找到数字');
            return;
        }

        // 提取数字
        const originalNumber = numberMatch[0];
        let incrementedNumber;
        
        // 检查是否包含小数点
        if (originalNumber.includes('.')) {
            // 如果是小数，只增加小数点后面的部分
            const parts = originalNumber.split('.');
            const integerPart = parts[0];
            const decimalPart = parseInt(parts[1]) + 1;
            incrementedNumber = `${integerPart}.${decimalPart}`;
        } else {
            // 如果是整数，直接加1
            incrementedNumber = (parseInt(originalNumber) + 1).toString();
        }
        
        // 替换内容中的数字
        const newContent = content.replace(originalNumber, incrementedNumber);
        
        // 构建新的行文本
        const newLineText = lineText.substring(0, secondPipeIndex + 1) + 
                            newContent + 
                            lineText.substring(thirdPipeIndex);
        
        // 替换整行文本
        editor.edit(editBuilder => {
            editBuilder.replace(line.range, newLineText);
        }).then(success => {
            if (success) {
                vscode.window.showInformationMessage('数字已成功增加');
            } else {
                vscode.window.showErrorMessage('编辑操作失败');
            }
        });
    });

    context.subscriptions.push(disposable);
}

export function deactivate() {}