import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
	console.log('插件 "识别当前行日期修改成今天的日期" 已激活');

	let disposable = vscode.commands.registerCommand('update-date-to-today.updateDate', () => {
		const editor = vscode.window.activeTextEditor;
		if (!editor) {
			vscode.window.showInformationMessage('没有打开的编辑器');
			return;
		}

		const document = editor.document;
		const selection = editor.selection;
		const line = document.lineAt(selection.active.line);
		const lineText = line.text;

		// 匹配所有支持的日期格式
		const westernDateRegex = /\b(\d{4})[-./](\d{1,2})[-./](\d{1,2})\b/g;
		
		// 简化的中文日期正则表达式
		const chineseDateRegex = /(\d{4})年([0-9]{1,2})月([0-9]{1,2})日/g;
		
		// 测试用的日期字符串，用于调试
		console.log('测试日期匹配:', chineseDateRegex.test('2025年1月3日'), chineseDateRegex.test('2025年01月03日'));
		
		let match;
		let updatedText = lineText;
		let hasMatches = false;

		// 获取当前日期
		const today = new Date();
		const year = today.getFullYear();
		const month = today.getMonth() + 1;
		const day = today.getDate();
		
		// 准备所有格式的当前日期
		const paddedMonth = month.toString().padStart(2, '0');
		const paddedDay = day.toString().padStart(2, '0');

		// 处理西方日期格式
		while ((match = westernDateRegex.exec(lineText)) !== null) {
			hasMatches = true;
			const fullMatch = match[0];
			const separator = fullMatch.includes('.') ? '.' : (fullMatch.includes('-') ? '-' : '/');
			const replacement = `${year}${separator}${paddedMonth}${separator}${paddedDay}`;
			updatedText = updatedText.replace(fullMatch, replacement);
		}
		
		// 处理中文日期格式
		while ((match = chineseDateRegex.exec(lineText)) !== null) {
			hasMatches = true;
			const fullMatch = match[0];
			const replacement = `${year}年${paddedMonth}月${paddedDay}日`;
			updatedText = updatedText.replace(fullMatch, replacement);
		}

		if (hasMatches) {
			// 先更新当前行的日期
			editor.edit(editBuilder => {
				editBuilder.replace(line.range, updatedText);
			}).then(success => {
				if (success) {
					// 日期已更新，接下来处理行移动
					const totalLines = document.lineCount;
					let headerLine = -1;
					let separatorLine = -1;

					// 向上查找表头和分隔线
					for (let i = selection.active.line; i >= 0; i--) {
						const text = document.lineAt(i).text.trim();
						if (text.match(/^\|\s*[-:]+\s*\|/)) {
							separatorLine = i;
							// 继续向上找表头
							for (let j = i - 1; j >= 0; j--) {
								const headerText = document.lineAt(j).text.trim();
								if (headerText.startsWith('|') && headerText.endsWith('|')) {
									headerLine = j;
									break;
								}
							}
							break;
						}
					}

					if (headerLine !== -1 && separatorLine !== -1 && selection.active.line > separatorLine) {
						// 重新获取已更新的行内容
						const updatedLineText = document.lineAt(selection.active.line).text;
						editor.edit(editBuilder => {
							// 删除当前行
							editBuilder.delete(document.lineAt(selection.active.line).rangeIncludingLineBreak);
							// 在分隔线下插入
							const insertPos = document.lineAt(separatorLine).range.end;
							editBuilder.insert(insertPos, '\n' + updatedLineText);
						}).then(moveSuccess => {
							if (moveSuccess) {
								vscode.window.showInformationMessage('日期已更新并移动到表格首行');
								// 移动光标到新插入的表格首行
								const newLine = separatorLine + 1;
								const newLineRange = document.lineAt(newLine).range;
								const newSelection = new vscode.Selection(newLineRange.start, newLineRange.start);
								editor.selection = newSelection;
								editor.revealRange(newLineRange, vscode.TextEditorRevealType.InCenter);
							}
						});
					} else {
						vscode.window.showInformationMessage('日期已更新');
					}
				}
			});
		} else {
			vscode.window.showInformationMessage('当前行未找到日期');
		}
	});

	context.subscriptions.push(disposable);
}

export function deactivate() {}