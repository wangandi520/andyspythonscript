import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
	let disposable = vscode.commands.registerCommand('update-date-to-today.updateDate', () => {
		const editor = vscode.window.activeTextEditor;
		if (!editor) {
			vscode.window.setStatusBarMessage('没有打开的编辑器', 3000);
			return;
		}
		const document = editor.document;
		const selection = editor.selection;
		const line = document.lineAt(selection.active.line);
		const lineText = line.text;
		// 匹配所有支持的日期格式
		const westernDateRegex = /\b(\d{4})[-./](\d{1,2})[-./](\d{1,2})\b/g;
		// 简化的中文日期正则表达式
		const chineseDateRegex = /(\d{4})年([0-9]{1,2})月([0-9]{1,2})日/g;
		let match;
		let updatedText = lineText;
		let hasMatches = false;
		// 获取当前日期
		const today = new Date();
		const year = today.getFullYear();
		const month = today.getMonth() + 1;
		const day = today.getDate();
		// 准备所有格式的当前日期
		const paddedMonth = month.toString().padStart(2, '0');
		const paddedDay = day.toString().padStart(2, '0');
		// 处理西方日期格式
		while ((match = westernDateRegex.exec(lineText)) !== null) {
			hasMatches = true;
			const fullMatch = match[0];
			const separator = fullMatch.includes('.') ? '.' : (fullMatch.includes('-') ? '-' : '/');
			const replacement = `${year}${separator}${paddedMonth}${separator}${paddedDay}`;
			updatedText = updatedText.replace(fullMatch, replacement);
		}
		// 处理中文日期格式
		while ((match = chineseDateRegex.exec(lineText)) !== null) {
			hasMatches = true;
			const fullMatch = match[0];
			const replacement = `${year}年${paddedMonth}月${paddedDay}日`;
			updatedText = updatedText.replace(fullMatch, replacement);
		}
		if (hasMatches) {
			editor.edit(editBuilder => {
				editBuilder.replace(line.range, updatedText);
			}).then(success => {
				if (success) {
					vscode.window.setStatusBarMessage('日期已更新', 3000);
				}
			});
		} else {
			vscode.window.setStatusBarMessage('当前行未找到日期', 3000);
		}
	});

	context.subscriptions.push(disposable);
}

export function deactivate() {}