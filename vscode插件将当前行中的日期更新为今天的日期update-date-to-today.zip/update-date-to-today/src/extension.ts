import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
	console.log('插件 "识别当前行日期修改成今天的日期" 已激活');

	let disposable = vscode.commands.registerCommand('update-date-to-today.updateDate', () => {
		const editor = vscode.window.activeTextEditor;
		if (!editor) {
			vscode.window.showInformationMessage('没有打开的编辑器');
			return;
		}

		const document = editor.document;
		const selection = editor.selection;
		const line = document.lineAt(selection.active.line);
		const lineText = line.text;

		// 匹配多种日期格式: YYYY.MM.DD, YYYY.M.D, YYYY-MM-DD, YYYY-M-D
		const dateRegex = /\b(\d{4})[.-](\d{1,2})[.-](\d{1,2})\b/g;
		
		let match;
		let updatedText = lineText;
		let hasMatches = false;

		// 获取当前日期
		const today = new Date();
		const year = today.getFullYear();
		const month = today.getMonth() + 1; // 月份从0开始
		const day = today.getDate();
		
		// 准备不同格式的当前日期
		const formattedDateDot = `${year}.${month}.${day}`;
		const formattedDateDotPadded = `${year}.${month.toString().padStart(2, '0')}.${day.toString().padStart(2, '0')}`;
		const formattedDateDash = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;

		while ((match = dateRegex.exec(lineText)) !== null) {
			hasMatches = true;
			const fullMatch = match[0];
			const separator = fullMatch.includes('.') ? '.' : '-';
			const hasPadding = fullMatch.length > 8; // 简单判断是否有前导零

			// 根据原始日期格式选择替换格式
			let replacement;
			if (separator === '.') {
				replacement = hasPadding ? formattedDateDotPadded : formattedDateDot;
			} else {
				replacement = formattedDateDash;
			}

			updatedText = updatedText.replace(fullMatch, replacement);
		}

		if (hasMatches) {
			editor.edit(editBuilder => {
				editBuilder.replace(line.range, updatedText);
			}).then(success => {
				if (success) {
					vscode.window.showInformationMessage('日期已更新');
				}
			});
		} else {
			vscode.window.showInformationMessage('当前行未找到日期');
		}
	});

	context.subscriptions.push(disposable);
}

export function deactivate() {}